from collections import deque

def load_maze(file_path):
    maze = []
    with open(file_path, "r") as f:
        for line in f:
            maze.append([int(x) for x in line.strip().split()])
    return maze

def bfs(maze, start, end):
    rows, cols = len(maze), len(maze[0])
    directions = [(-1,0), (1,0), (0,-1), (0,1)]
    queue = deque([start])
    visited = set([start])
    parent = {start: None}

    while queue:
        current = queue.popleft()
        if current == end:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            path.reverse()
            return path
        for d in directions:
            nr, nc = current[0]+d[0], current[1]+d[1]
            if 0<=nr<rows and 0<=nc<cols and maze[nr][nc]==0 and (nr,nc) not in visited:
                queue.append((nr,nc))
                visited.add((nr,nc))
                parent[(nr,nc)] = current
    return None

def dfs(maze, start, end):
    rows, cols = len(maze), len(maze[0])
    directions = [(-1,0), (1,0), (0,-1), (0,1)]
    stack = [start]
    visited = set([start])
    parent = {start: None}

    while stack:
        current = stack.pop()
        if current == end:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            path.reverse()
            return path
        for d in directions:
            nr, nc = current[0]+d[0], current[1]+d[1]
            if 0<=nr<rows and 0<=nc<cols and maze[nr][nc]==0 and (nr,nc) not in visited:
                stack.append((nr,nc))
                visited.add((nr,nc))
                parent[(nr,nc)] = current
    return None

def print_maze_path(maze, path):
    maze_copy = [row[:] for row in maze]
    for r,c in path:
        maze_copy[r][c] = "*"
    for row in maze_copy:
        print(" ".join(str(x) if x!="*" else "*" for x in row))

if __name__ == "__main__":
    maze_file = "sample_mazes/maze1.txt"
    maze = load_maze(maze_file)
    start = (0,0)
    end = (len(maze)-1, len(maze[0])-1)

    print("BFS Path:")
    bfs_path = bfs(maze, start, end)
    if bfs_path:
        print_maze_path(maze, bfs_path)
    else:
        print("No path found using BFS!")

    print("\nDFS Path:")
    dfs_path = dfs(maze, start, end)
    if dfs_path:
        print_maze_path(maze, dfs_path)
    else:
        print("No path found using DFS!")
